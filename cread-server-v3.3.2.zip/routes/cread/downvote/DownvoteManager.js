/**
 * Created by avnee on 05-03-2018.
 */
'use-strict';

var express = require('express');
var router = express.Router();

var config = require('../../Config');

var _auth = require('../../auth-token-management/AuthTokenManager');
var BreakPromiseChainError = require('../utils/BreakPromiseChainError');

var downvoteutils = require('./DownvoteUtils');
var entityutils = require('../entity/EntityUtils');
var utils = require('../utils/Utils');

router.post('/on-click', function (request, response) {

    console.log("request is " + JSON.stringify(request.body, null, 3));

    var uuid = request.body.uuid;
    var authkey = request.body.authkey;
    var entityid = request.body.entityid;
    var register = request.body.register;

    var connection;
    var requesterdetails;

    _auth.authValid(uuid, authkey)
        .then(function (details) {
            requesterdetails = details;
            return config.getNewConnection();
        }, function () {
            response.send({
                tokenstatus: 'invalid'
            });
            response.end();
            throw new BreakPromiseChainError();
        })
        .then(function (conn) {
            connection = conn;
            return utils.beginTransaction(connection);
        })
        .then(function () {
            return downvoteutils.registerDownvote(connection, register, uuid, entityid);
        })
        .then(function () {
            //Remove entity from explore if the downvoter is a team member
            if(register && uuid === config.getNishantMittalUUID()){
                return entityutils.removeEntityFromExplore(connection, entityid);
            }
            //Put entity to explore if the un-downvoter is a team member
            else if(!register && uuid === config.getNishantMittalUUID()){
                return entityutils.putEntityToExplore(connection, entityid);
            }
        })
        .then(function () {
            return utils.commitTransaction(connection, undefined);
        }, function (err) {
            return utils.rollbackTransaction(connection, undefined, err);
        })
        .then(function () {
            response.send({
                tokenstatus: 'valid',
                data: {
                    status: 'done'
                }
            });
            response.end();
            throw new BreakPromiseChainError();
        })
        .catch(function (err) {
            config.disconnect(connection);
            if(err instanceof BreakPromiseChainError){
                //Do nothing
            }
            else{
                console.error(err);
                response.status(500).send({
                    message: 'Some error occurred at the server'
                }).end();
            }
        });

});

module.exports = router;