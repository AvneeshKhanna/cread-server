'use strict';

var MID = '52cd743e-2f83-41b8-8468-ea83daf909e7';

module.exports = {
  MID : MID
};